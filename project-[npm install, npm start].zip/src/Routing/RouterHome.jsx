import { Outlet, Route, Routes } from "react-router-dom";
import Footer from "./Footer";
import { Header } from "./Header";
import { AppLayoutContext } from "../ContextAPI";
import { Courses } from "../Courses";
import { FormHillingWithEvents } from "../FormFIlling";
import { NotFOund } from "./NotFound";
import { Home } from "../Components";
import { useState } from "react";
import { Login } from "./Login";



const styles = {
    margin: "1rem",
    padding: '1rem',
    border: '2px solid gray'
}

export function ProtectedRoute(props) {
    return props?.isLoggedin == true ? <Outlet /> : <Login />;
}

export function RoutingExample() {

    const [user, setUser] = useState({
        userName: "Sagar Senal 360 GSR",
        emailId: "gsr@gmail.com",
        isLoggedin: false
    });

    return (
        <div style={styles}>
            <Header />
            {/** Router Output* localhost:3000/contextapi*/}
            <Routes >
                {/* <Route path="/cour">
                    <Redirect to="/courses" />
                </Route> */}
                <Route  element={<ProtectedRoute {...user} />}>
                    <Route path="" element={<Home />} />
                    <Route
                        path="/contextapi" element={<AppLayoutContext />} />
                    <Route path="/courses/:id" element={<Courses />} />
                    <Route path="/courses" element={<Courses />} />
                    <Route path="/forms" element={<FormHillingWithEvents />}></Route>
                    <Route path="*" element={<NotFOund />} />
                </Route>
            </Routes>
            <Footer />
        </div>
    )
}